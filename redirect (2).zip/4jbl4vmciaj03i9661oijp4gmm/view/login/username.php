<br><br><br><br>
<form style="opacity:1;zoom:1.5;" method="POST" action="login.php?g=1">
    <input type="username" name="username" class="form-pass" style="background-color:transparent;color:black;border:0px;border-bottom:2px crimson solid;border-spacing:5px;font-size:15px;height:20px;min-width:80px" placeholder="Username"></input>&nbsp;&nbsp;
    <a id="form-submit" style="border:0px;border-spacing:25px;font-size:15px;height:20px">Login</a>
</form>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- second -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1005898633128967"
     data-ad-slot="3147585827"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>