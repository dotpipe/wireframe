<?php

namespace Adoms\crud;
 
require_once ('../vendor/autoload.php');
$login = new db("../Adoms/config/config.json");

$record = $login->read(["users" => ["site_id", "username"]], "username = '" . $_COOKIE['username'] . "' AND password = '" . $_COOKIE['password'] . "'");

if ($record->num_rows == 1) {
    header("Location: ../");
}

?>
