# adoms
PHP Library and MVC


To use the chat aspect, just include:

Adoms\src\chat\outchat.php

