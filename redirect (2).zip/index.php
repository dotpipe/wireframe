<?php 

    header("Location: https://www.esay.cc/index2.php");

?>