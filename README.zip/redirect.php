<?php

namespace wireframe;

if (!isset($_SESSION))
    session_start();

require 'vendor/autoload.php';

    

    $y = array();
    if ($_SESSION['TROLL'])
        $y = array("TROLL" => $_SESSION['TROLL'], "Duration" => "fixed", "grad_fee" => 0);
    else
        $y = array("TROLL" => session_id(), "Duration" => "limited", "grad_fee" => 0);

    $x = new PageControllers($y['TROLL']);
    $x->newView("index");
    $x->mvc['index']->addModelField("SESSID");
    $x->mvc['index']->addModelValid("Duration",'/(fixed|limited)/');
    $x->mvc['index']->addModelData('index', $y);
    
    $x->mvc['index']->view->addPartial(session_id());
    $x->mvc['index']->addModelData('index', $y);
    $x->mvc['index']->addModelData('friends', $z);
    //$x->mvc['index']->view->removeDependency("shared","index.php");
    $x->mvc['index']->view->writePage("index");
    $x->save();
    $x = $x->loadJSON();
    echo json_encode($x);
    $x->mvc['index']->view->createAction("Deploy");
    $x->paginateModels('index', 'index.php',0,3);
    echo "<br><br><br>";
    echo json_encode($x);
