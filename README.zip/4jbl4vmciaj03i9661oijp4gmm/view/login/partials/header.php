<html>
<title>eSay - Your avenue to distributed content</title>
<head></head>
<body style="margin-top:-40px;margin-bottom:0px;margin-right:0px">

<br>
<table>
    <tr>
        <td>
        <table style="width:640px">
            <tr>
                <td colspan="2" style="height:45px">
                &nbsp;
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align:center">
                <h2>Hello! And Welcome to eSay.</h2>
                </td>
            </tr>
            <tr>
                <td>
        Hi, eSay here. I'm a programming language built to a CDN specification, 
        with practical approaches admittedly like low level programming, but with an easy API to follow up.
        Not everyone can have this going on the spot. But I guarantee your likelihood of enduring praise.
        I will eagerly use my qualifications to bring your desire to your own company website.
        Tools available allow creation and the manifestation of a desired platform for you and your endpoints, the consumer.
        I don't believe you'll find much wrong here. And, once we have your assets aligned to yoru likening, 
        we will keep you burning more brighter than a star among the heavens.
                </td>
                <td style="padding:25px">
        By essentially valuing each customer differently, our costs, and inso saying, our fees
        will remain inexpensive. I'm not a greedy language, and I don't take much to learn.
        As for your costs, we will keep up a grade on your traffic and update you with changes as your company grows
        to keep you right on target; from small to medium, and even large faceted sites.
                </td>
            </tr>
            <tr>
                <td colspan="2" style="padding:35px">

        I, eSay, help you to build a certain and successful connection with your customers.
        If you need it, we can build a solution for you in eSay. Then your customers will be served anytime on.
        You and eSay will build a class of trust, and eSay will grow as a language of programming. It's a framework for PHP
        after all. The companionship we will never lose sight of will be our bottom line and I can tell you its small in the real world.
        We will create a relationship between the love you have of your company, and the online exposure between you, our site and others.
                </td>
            </tr>
            <tr>
                <td colspan="2">
                <br>
        I will keep our files online and we will help direct traffic as quickly as possible. We have tools at the ready to properly deploy
        your site as quickly as it can.
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                <br>
        Therefore, you will have your own personal directory structure. Thus, within that directory heirarchy
        the site you make will be completely suited against scratches, because we will backup nightly.
        And we will stand it on your own unique abilities to program and markup web pages. As much, I wish you
        to have the most belief in your sites connectivity and security you can have, so we'll use certain fundamentals
        CDNs have to explore the normally gritty, grief-ridden exponentiation of recursive site design. eSay should make it much
        easier to synergize your specific site with the fastest protocols and have you feeling as though you are the clear winner
        for your continued use of our end of this relationship. We could tell you more, but we'd like you to think and to talk
        about it with us by email. Please! Contact the eSay Team at <a href="mailto:inland14@live.com">inland14@live.com</a>.
        <br><br><br>
                </td>
            </tr>
        </table>
        </td>
        <td style="horizontal-align:center;vertical-align:top;padding:20px;width:48%;background:goldenrod">
            <br><br>
            By using the company, you will be able to expand your own evolved processes. As not only the site with the easiest
            API, we also offer quite a bargain for our bandwidth.
            <br><br>
            <table style="vertical-align:top;">
                <tr>
                    <td style="padding:20px;">
                        <br><br>
                        Sites with: < 7,000,000 hits a month:
                        $0.0004 a hit<br><br>
                        Sites with: < 15,000,000 hits a month:
                        $0.0008 a hit<br><br>
                        Sites with: < 100,000,000 hits a month:
                        $0.0015 a hit<br><br>
                    </td>
                </tr>
            </table>
        </td>
        <td style="padding:10px;width:48%;background:goldenrod">
        &nbsp;
        </td>
    </tr>
</table>
</body></html>