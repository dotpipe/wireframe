<?php

namespace wireframe;

use wireframe\crud\db;

if (!isset($_SESSION))
    session_start();

require 'vendor/autoload.php';

$db = new db();

    $returned_query = $db->read(array("cdn" => ['site_id']),'`username` = "use" LIMIT 1');
    if (\is_array($returned_query) && count($returned_query) > 0) {
        \setcookie('USID',$returned_query[0]['site_id'],(time() + (4*60*60)));
    }
    else if (isset($_GET['username']) && isset($_GET['password'])) {
        \setcookie('USID',sessionid(),(time() + (60*60)));
        $vals = array (
            "id" => NULL,
            "username" => "use",
            "email" => "ya",
            "pictures" => "pics",
            "site_ref" => "0",
            "site_id" => $_COOKIE['USID'],
            "grad_fee" => "0",
            "fee" => 10,
            "refered_by" => "referal",
            "deal" => NULL
        );
        $db->create($vals,"cdn");
        
    }
    
    $x = new PageControllers($_COOKIE['USID']);

    $upass = ["username" => "", "password" => ""];
    if (isset($_GET['username']) && isset($_GET['password']))
    {
        $upass['username'] = $_GET['username'];
        $upass['password'] = $_GET['password'];
    }
    $x->newView("login");
    $x->mvc['login']->addModelField("username");
    $x->mvc['login']->addModelField("password");
    $x->mvc['login']->addModelValid("username",'/[A-z0-9_]{3,}/', "Illegal Username, must be 3 chars long. Letters, numbers, and underscore");
    $x->mvc['login']->addModelValid("password",'/[[A-z]{3,}[0-9]{3,}[_!@#$%^&*\(\)\\]{2,}]{9,}/', "9+ characters of 3+ letters, 3+ Numbers, 2+ punctuations from number keys or underscore");
    $x->mvc['login']->addModelData("username", $upass);
    $x->mvc['login']->addModelData("password", $upass);
    $x->mvc['login']->view->addPartial("header.php");
    $x->mvc['login']->view->addShared("header.php");
    $x->mvc['login']->view->writePage("index");
    $x->paginateModels("login","index.php");
    $x->save();
    $x = $x->loadJSON();
    echo json_encode($x);
    
    echo "<br><br><br>";
    echo json_encode($x);
