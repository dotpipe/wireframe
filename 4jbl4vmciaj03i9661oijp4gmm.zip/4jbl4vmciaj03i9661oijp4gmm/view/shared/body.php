<table>
    <tr>
        <td id="bg">
        <?php require_once("home.php"); ?>
        </td>
        <td style="border-spacing:25px;opacity:1;horizontal-align:center;vertical-align:top;padding:20px;padding-top:55px;">
            <div style="border:black 2px solid;background:white;box-shadow:2px 2px 2px lightgray;padding:5px;">By using the company, you will be able to expand your own evolved processes. As not only the site with the easiest
            API, we also offer quite a bargain for our bandwidth.</div>
            <br><br>
            <table align="center" style="width:200px;vertical-align:top;">
                <tr>
                    <td style="background:white;border:lightblue 5px solid;border-radius:25px;text-align:center;padding:20px;">
                        <center><b style="text-shadow:2px 2px 2px lightgray;text-align:center;font-size:20">Freedom to Advertise</b><br>
                        Monetize your way.<br>
                        <br><b style="font-size:18;text-shadow:2px 2px 2px lightgray;">Hits/mo Cost Tree</b></center>
                        <hr width="50%">
                        <?php printf("<h4>&lt;= %s %.4f</h4>","10,000,000", 0.0003); ?>
                        <?php printf("<h4>&lt;= %s %.4f</h4>","5,000,000", 0.0002); ?>
                        <?php printf("<h4>&lt;= %s %.4f</h4>","700,000", 0.0001); ?>
                        <?php printf("<h4>&lt;= %s %.5f</h4>","20,000", 0.00007); ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h2 style="font-family:SegoeScript;font-size:30px;float:right"><i>if you say it,<br>you Anthzm it.. </i></h2>
                    </td>
                </tr>
                <tr>
                    <td style="opacity:0.7;padding:10px;vertical-align:bottom;cursor:default"><br><br>© <?= date("Y",time()); ?> By Pirodock</td>
                </tr> 
            </table>
        </td>
        <td style="width:120px;padding:10px;vertical-align:top;">
            <img src="view/pictures/sidebar.webp"/>
        </td>
        <td width="150px">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
            <!-- second -->
            <ins class="adsbygoogle"
                style="display:block"
                data-ad-client="ca-pub-1005898633128967"
                data-ad-slot="3147585827"
                data-ad-format="auto"
                data-full-width-responsive="true"></ins>
        <script>
            (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
        </td>
    </tr>
</table>