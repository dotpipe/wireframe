
<br><br><br><br>
<?php setcookie("username", $_POST['username'], time() + (60 * 60 * 24)); ?>
<form style="opacity:1;zoom:1.5;" method="POST" action="login.php?g=0">
    <input type="password" name="password" class="form-pass" style="color:black;border:0px;background-color:transparent;border-bottom:2px crimson solid;border-spacing:5px;font-size:15px;height:20px;min-width:80px" placeholder="Password"></input>
    <button type="submit" id="form-submit" style="background-color:transparent;border:0px;border-spacing:25px;font-size:15px;height:20px">Login</button>
</form>
<a href="login.php" style="color:black;">Go Back</a>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- second -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1005898633128967"
     data-ad-slot="3147585827"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>