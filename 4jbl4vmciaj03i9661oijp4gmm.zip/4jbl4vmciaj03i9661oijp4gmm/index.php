<?php

	include_once("view/shared/skeleton.php");

?>
