<?php
    include_once("view/shared/header.php");
    echo "<center>";
    include_once("view/register/front.php");
    echo "</center>";
?>