<?php
	include_once(__DIR__ . "/view/shared/skeleton.php");
?>
