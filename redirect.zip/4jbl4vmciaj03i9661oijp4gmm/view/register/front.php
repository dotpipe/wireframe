<script src="../Adoms/src/routes/pipes.js"></script>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<form style="opacity:1;zoom:1.5;">
    <input type="username" class="form-register" style="background-color:transparent;color:black;border:0px;border-bottom:2px crimson solid;border-spacing:5px;font-size:15px;height:20px;min-width:80px" placeholder="username"/>&nbsp;&nbsp;
    <input type="password" class="form-register" style="background-color:transparent;color:black;border:0px;border-bottom:2px crimson solid;border-spacing:5px;font-size:15px;height:20px;min-width:80px" placeholder="password"/>&nbsp;&nbsp;
    <input type="email" class="form-register" style="background-color:transparent;color:black;border:0px;border-bottom:2px crimson solid;border-spacing:5px;font-size:15px;height:20px;min-width:80px" placeholder="email"/>&nbsp;&nbsp;
    <input type="phone" class="form-register" style="background-color:transparent;color:black;border:0px;border-bottom:2px crimson solid;border-spacing:5px;font-size:15px;height:20px;min-width:80px" placeholder="phone"/>&nbsp;&nbsp;
    <a id="form-submit" goto="login.php" ajax="login.php" style="border:0px;border-spacing:25px;font-size:15px;height:20px">Register</a>
</form>