<br><br><br><br>
<form style="opacity:1;zoom:1.5;">
    <input type="password" class="form-pass" contenteditable style="color:black;border:0px;background-color:transparent;border-bottom:2px crimson solid;border-spacing:5px;font-size:15px;height:20px;min-width:80px" placeholder="Password">
    <button type="submit" id="form-submit" insert-in="form-login" ajax="view/login/pass.php" style="background-color:transparent;border:0px;border-spacing:25px;font-size:15px;height:20px">Login</button>
</form>
<a href="login.php" style="color:black;">Go Back</a>