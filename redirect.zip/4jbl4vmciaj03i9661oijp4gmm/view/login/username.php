<br><br><br><br>
<form style="opacity:1;zoom:1.5;">
    <input type="username" class="form-pass" style="background-color:transparent;color:black;border:0px;border-bottom:2px crimson solid;border-spacing:5px;font-size:15px;height:20px;min-width:80px" placeholder="Username"></input>&nbsp;&nbsp;
    <a id="form-submit" insert-in="login-frame" ajax="view/login/pass.php" style="border:0px;border-spacing:25px;font-size:15px;height:20px">Login</a>
</form>