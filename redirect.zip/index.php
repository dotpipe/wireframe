<?php

namespace Adoms\src\crud;

use Adoms\src\wireframe;

if (!isset($_SESSION))
    session_start();

require 'vendor/autoload.php';

$db = new db('Adoms\config\config.json');
$bool_user = false;

/// Collect information to see if a visitor is new or not
/// Next see how many times they have visited.
/// Cache the user to have a token for their IP
/// User token becomes their site_id in the database
$returned = $db->read(array("visitors" => ['hits', 'site_id', 'is_user']), '`IP` = "' . $_SERVER['REMOTE_ADDR'] . '"');
if (\is_array($returned) && \count($returned) > 0) {
    if ($returned[0]['site_id'] == '/') {
        $returned[0]['site_id'] = session_id();
    }
    $var = array (
        "hits" => ($returned[0]['hits'] + 1),
        "site_id" => $returned[0]['site_id']
    );
    $db->update("visitors", $var, "`IP` = \"" . $_SERVER['REMOTE_ADDR'] . "\"");
    session_destroy();
    session_id($returned[0]['site_id']);
    session_start();
    setcookie("PHPSESSID", $returned[0]['site_id'], time() + (60 * 60 * 24 * 60));
    $bool_user = true;
}
else {
    $var = array(
        "id" => NULL,
        "IP" => $_SERVER['REMOTE_ADDR'],
        "hits" => 1,
        "site_id" => session_id(),
        "is_user" => 0,
        "date" => date("H",time())
    );
    $db->create($var,"visitors");
    setcookie("PHPSESSID", session_id(), time() + (60 * 60 * 24 * 60));
}
/// Get a JUMP target for the meantime
/// This will have the ability to change everytime
/// a user comes to the site. Then more than one
/// person can see the one JUMP and later another
/// gets a turn.
$got_it = [];
{
    $count = $db->read(array("users" => ["id", "site_id"] ), "1");
    $rows = $count;
    srand(time());
    $rand = rand(1, count($rows));
    for ($i = 0; $i < $rand  && $i < $rows; $i++) {
        $got_it = $count[$i];
    }
    file_put_contents("random_target_jump",$got_it['site_id']);
    $_SESSION['RAND'] = $got_it['site_id'];
}

    $returned = "";
    
    /// LOGIN FOR THE USERS WHO ARE ALREADY REGISTERED
    if ($bool_user != true && !isset($_GET['new']) && isset($_GET['username']) && isset($_GET['password'])){
        $hash_temp = password_hash($_COOKIE['PHPSESSID'],0);
        $rehash = password_hash($hash_temp,0);
        $returned = $db->read(array("users" => ['site_id']),'`username` = "' . $_GET['username'] . '" AND `password` = "' . password_hash($rehash,0) . '"');
        session_destroy();
        session_id($returned[0]['site_id']);
        session_start();
        $_SESSION['RAND'] = $got_it['site_id'];
    }
    /// NEW GUEST
    if ($bool_user != true && isset($returned[0]['site_id'])) {
        session_destroy();
        session_id($returned[0]['site_id']);
        session_start();
        
        $_SESSION['RAND'] = $got_it['site_id'];
        \setcookie('PHPSESSID',$returned[0]['site_id'], time() + (60 * 60 * 24 * 60));
        \header("Location: " . __DIR__ . "/" . $_COOKIE['PHPSESSID'] . "/");
    }
    /// SETUP NEW USER
    /// NOT FINISHED!
    else if ($bool_user != true && isset($_GET['new']) && isset($_GET['username'])) {
        session_destroy();
        session_id($returned[0]['site_id']);
        session_start();
        
        $_SESSION['RAND'] = $got_it['site_id'];
        $hash_temp = password_hash($_COOKIE['PHPSESSID'],0);
        $rehash = password_hash($hash_temp,0);
        $vals = array (
            "id" => NULL,
            "username" => $_GET['username'],
            "password" => $rehash = password_hash($rehash,0),
            "email" => NULL,
            "site_id" => $_COOKIE['PHPSESSID'],
            "grad_fee" => 0.0002,
            "month" => date("m",time()),
            "views_month" => 0,
            "fee" => 0,
            "refered_by" => NULL,
            "deal" => NULL,
            "views_total" => 0
        );
        $db->create($vals,"users");
        $_SESSION['SESSION_ID'] = $rehash;
        $returned = $db->read(array("users" => ['site_id']),'`username` = "' . $_GET['username'] . '" AND `password` = "' . $_GET['password'] . '"');
        $var = array(
            "is_user" => 1
        );
        $db->update("visitors", $var, "`IP` = \"" . $_COOKIE['PHPSESSID'] . "\"");
        if (\is_array($returned) && \count($returned) > 0) {
            \setcookie('PHPSESSID',$returned[0]['site_id'],time() + (60 * 60 * 24 * 60));
            \header("Location: " . __DIR__ . "/" . $_COOKIE['PHPSESSID'] . "/");
        }
        else {
            \setcookie('PHPSESSID',\session_id(),time() + (60 * 60 * 24 * 60));
            \header("Location: 4jbl4vmciaj03i9661oijp4gmm/");
        }
    }
    /// Already a user and I'm looking for the session they use
    /// They'll be taken to their own site. JUMPs will be on their page
    else if ($bool_user == true && isset($_COOKIE['PHPSESSID'])) {
        $returned = $db->read(array("users" => ['site_id']),'`site_id` = "' . $_COOKIE['PHPSESSID'] . '"');
        
        if (\is_array($returned) && count($returned) > 0) {
            \session_destroy();
            \session_id($returned[0]['site_id']);
            \session_start();
            
            $_SESSION['RAND'] = $got_it['site_id'];
            \setcookie('PHPSESSID',$returned[0]['site_id'],time() + (60 * 60 * 24 * 60));
            \header("Location: " . __DIR__ . "/" . $_COOKIE['PHPSESSID'] . "/");
        }
        else {
            unset($_COOKIE['PHPSESSID']);
            \header("Location: redirect.php");
        }
    }
    /// IDENTIFY OLD USER WITH NEW PHPSESSID (RESET TOKEN)
    /// NOT DONE!
    else if ($bool_user == true) {
        setcookie("PHPSESSID",session_id(), time() + (60 * 60 * 24 * 60));
    } 
    /// Last chance. Send them to the site's sign up page.
    $_SESSION['RAND'] = $got_it['site_id'];
    \header("Location: 4jbl4vmciaj03i9661oijp4gmm/");

?>